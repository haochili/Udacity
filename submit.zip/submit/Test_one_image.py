import matplotlib.image as mpimg
import matplotlib.pyplot as plt
import numpy as np
import cv2
import glob
import time
import pickle
from sklearn.svm import LinearSVC
from sklearn.preprocessing import StandardScaler
from skimage.feature import hog
from lesson_functions_search_classifier import *
from scipy.ndimage.measurements import label

#dist_pickle = pickle.load(open("svc_pickle_small_sample.p", "rb" ))
dist_pickle = pickle.load(open("svc_search_classify_only.p", "rb" ))
svc = dist_pickle["svc"]
X_scaler = dist_pickle["scaler"]
orient = dist_pickle["orient"]
pix_per_cell = dist_pickle["pix_per_cell"]
cell_per_block = dist_pickle["cell_per_block"]
spatial_size = dist_pickle["spatial_size"]
hist_bins = dist_pickle["hist_bins"]

color_space = 'RGB' # Can be RGB, HSV, LUV, HLS, YUV, YCrCb
orient = 9  # HOG orientations
pix_per_cell = 8 # HOG pixels per cell
cell_per_block = 2 # HOG cells per block
hog_channel = 'ALL' # Can be 0, 1, 2, or "ALL"
spatial_size = (64, 64) # Spatial binning dimensions
hist_bins = 64    # Number of histogram bins
spatial_feat = True # Spatial features on or off
hist_feat = True # Histogram features on or off
hog_feat = True # HOG features on or off
y_start_stop96 = [400, 600] # Min and max in y to search in slide_window()
y_start_stop64 = [400, 600]
y_start_stop32 = [400, 500]

print('Start to test with single image')
#from lesson_functions_hog import *
t=time.time()
# Signal image testing  
image = mpimg.imread('test4.jpg')
draw_image = np.copy(image)/255

# Uncomment the following line if you extracted training
# data from .png images (scaled 0 to 1 by mpimg) and the
# image you are searching is a .jpg (scaled 0 to 255)
draw_image = draw_image.astype(np.float32)
t2=time.time()
print(round(t2-t, 2), 'Seconds to load a singal image')
windows = []
win96 = slide_window(draw_image, x_start_stop=[None, None], y_start_stop=y_start_stop96, 
                    xy_window=(128, 128), xy_overlap=(0.7, 0.7))
win64 = slide_window(draw_image, x_start_stop=[None, None], y_start_stop=y_start_stop64, 
                    xy_window=(64, 64), xy_overlap=(0.8, 0.8))
win32 = slide_window(draw_image, x_start_stop=[None, None], y_start_stop=y_start_stop32, 
                    xy_window=(32, 32), xy_overlap=(0.7, 0.7))
    #find all possible windows and return a list of start/end coordinates

windows.extend(win96)
#print('win96 shape', np.shape(win96))
#print('win96 length', len(win96))
#print('windows length', len(windows))
windows.extend(win64)
#print('win64 length', len(win64))
#print('windows length', len(windows))
windows.extend(win32)
#print('win32 length', len(win32))
#print('windows length', len(windows))

#find all possible windows and return a list of start/end coordinates

hot_windows = search_windows(draw_image, windows, svc, X_scaler, color_space=color_space, 
                        spatial_size=spatial_size, hist_bins=hist_bins, 
                        orient=orient, pix_per_cell=pix_per_cell, 
                        cell_per_block=cell_per_block, 
                        hog_channel=hog_channel, spatial_feat=spatial_feat, 
                        hist_feat=hist_feat, hog_feat=hog_feat)                   

#Search window returns a list of window coordinates- part of "windows" list that is is determined to have cars features in the content of the window area. Search_window function makes feature vector for each window covered image, does feature rescale- to the same sacle of traning image, fit into classifer, and make preditions of the result. 

window_img = draw_boxes(image, hot_windows, color=(0, 0, 255), thick=6)
print('image shape:',np.shape(window_img))
print(np.max(window_img))
heat = np.zeros_like(image[:,:,0])
heat = add_heat(heat,hot_windows)
heat = apply_threshold(heat,9)
heatmap = np.clip(heat, 0, 255)
labels = label(heatmap)
draw_img = draw_labeled_bboxes(np.copy(image), labels)
t3 = time.time()
print(round(t3-t2, 2), 'Seconds to find cars in the singal image')
fig = plt.figure()
plt.subplot(221)
aa=plt.imshow(window_img)
plt.title('Test Image Outputs')
plt.subplot(222)
ab=plt.imshow(draw_img)
plt.title('Cut False Positive')
plt.subplot(223)
cd=plt.imshow(heatmap, cmap='hot')
plt.title('Heat Map')
fig.tight_layout()
#plt.show(ab)
plt.show(fig)