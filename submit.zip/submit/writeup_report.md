##Writeup Template
###You can use this file as a template for your writeup if you want to submit it as a markdown file, but feel free to use some other method and submit a pdf if you prefer.

---

**Vehicle Detection Project**

The goals / steps of this project are the following:

* Perform a Histogram of Oriented Gradients (HOG) feature extraction on a labeled training set of images and train a classifier Linear SVM classifier
* Optionally, you can also apply a color transform and append binned color features, as well as histograms of color, to your HOG feature vector. 
* Note: for those first two steps don't forget to normalize your features and randomize a selection for training and testing.
* Implement a sliding-window technique and use your trained classifier to search for vehicles in images.
* Run your pipeline on a video stream (start with the test_video.mp4 and later implement on full project_video.mp4) and create a heat map of recurring detections frame by frame to reject outliers and follow detected vehicles.
* Estimate a bounding box for vehicles detected.

[//]: # (Image References)
[image1]: ./examples/car_not_car.png
[image2]: ./examples/HOG_example.jpg
[image3]: ./examples/sliding_windows.jpg
[image4]: ./examples/sliding_window.jpg
[image5]: ./examples/bboxes_and_heat.png
[image6]: ./examples/labels_map.png
[image7]: ./examples/output_bboxes.png
[video1]: ./project_video.mp4

## [Rubric](https://review.udacity.com/#!/rubrics/513/view) Points
###Here I will consider the rubric points individually and describe how I addressed each point in my implementation.  

---
###Writeup / README

####1. Provide a Writeup / README that includes all the rubric points and how you addressed each one.  You can submit your writeup as markdown or pdf.  [Here](https://github.com/udacity/CarND-Vehicle-Detection/blob/master/writeup_template.md) is a template writeup for this project you can use as a guide and a starting point.  

You're reading it!

###Histogram of Oriented Gradients (HOG)

####1. Explain how (and identify where in your code) you extracted HOG features from the training images.

The code for this step is contained `search_classify.py`.

I started by reading in all the `vehicle` and `non-vehicle` images. For any data path that contains"non-vehicles", I put it into hte list of 'notcars', otherwise, put the image into cars list. (line 20)
Then I called the function `extract_features` in another file `lesson_functions_search_classifier.py` where the function `get_hog_features` is defined. 
This `get_hog_features` function calls the `hog` function that extract an images edge gradient characteristics into an feature array.

I used the `RGB` color space and HOG parameters of `orientations=9`, `pixels_per_cell=(8, 8)` and `cells_per_block=(2, 2)`

####2. Explain how you settled on your final choice of HOG parameters.

I used the the parameters described above to get an feature with lengh of 5292 that describes the gradient characteristics of a single training image. 

In addition, I used `bin_spatial` to resize the image into a 32 by 32 dimension and use .ravel() to flatten the 2D array into a 1D array with length of 3072. 

Moreover, I used `color_hist` to find out color histogram of the image wiht 32 color bins. The length of this feature is 96 for all 3 r, g and b channels. 

Together I stack the three features into a combined feature of length of 8460. Each training image is converted to such image characteristics feature  beore sent to the next step-training. 

####3. Describe how (and identify where in your code) you trained a classifier using your selected HOG features (and color features if you used them).

Before sending the data for training, there are necessary steps to do to shuffle and normalize the data. 
The cars and noncars lists are shuffled. All the images features are combined into a list called 'X'. I used `X_scaler = StandardScaler().fit(X)` and `scaled_X = X_scaler.transform(X)` to normalize the training set so the magnitude of each feature will be similar. 

I trained a linear SVM the 'X_train', 'y_train' splited from 'scaled_X' and 'y'. The .score() function is able to return a training accuracy around 96%

After training is completed, I stored the model 'svc', scaler... parameters into a svc_search_classify_only.p file so that the model can be stored for later usage of identifing vehicles. 
###Sliding Window Search

####1. Describe how (and identify where in your code) you implemented a sliding window search.  How did you decide what scales to search and how much to overlap windows?

I decided to search for existence of the vehicles with `slide_window` function where the identified size of window pass through all possible positions in hte allowed area in the image. The location cooridnates of the windows are passed into the `search_windows` function where each of the window image is passed through the model and predict the result whether there is a vehicle in the area covered by the window. If yes, then add the coordinates of the window into a `on_windows` list that is used later for heatmap filtering. 

![alt text][image3]

####2. Show some examples of test images to demonstrate how your pipeline is working.  What did you do to optimize the performance of your classifier?

I used RGB color space throughout training and testing by using mpimg.imread instead of cv2.imread function. Please take a look at the 'output_images' folder, the processed images for testing are saved inside. From the images, you may see some false positives. But these false positives are gone in the video. This is because when I combine several frames and fine the avg heat level of each frame, the false positive window's heat level is too low, thus being thrown out from the heatmap filter.

To rule out the tinny small windows that are drawn from noices, I changed the code in the `draw_labeled_bboxes` function and let the boxes with area < 1024 (namely 32x32) not drawn on the result image. 
In the output_images folder, the first image is the result of on_windows drawn on the image. The second image is the result after heatmap filter been applied to the first image. The last image is the heatmap. 

![alt text][image4]
---

### Video Implementation

####1. Provide a link to your final video output.  Your pipeline should perform reasonably well on the entire project video (somewhat wobbly or unstable bounding boxes are ok as long as you are identifying the vehicles most of the time with minimal false positives.)
Here's a [link to my video result](./project_video.mp4)

Please see the video result.mp4 attached with this document. 


####2. Describe how (and identify where in your code) you implemented some kind of filter for false positives and some method for combining overlapping bounding boxes.

I recorded the positions of positive detections in each frame of the video.  From the positive detections I created a heatmap and then thresholded that map to identify vehicle positions.  I then used `scipy.ndimage.measurements.label()` to identify individual blobs in the heatmap.  I then assumed each blob corresponded to a vehicle.  I constructed bounding boxes to cover the area of each blob detected.  

I averaged the consecutive 30 frames of image for the heatmap filter to cancel the noise from the environment. Also, the heat threshold is set to 10 for the heatmap filtering.  


---

###Discussion

####1. Briefly discuss any problems / issues you faced in your implementation of this project.  Where will your pipeline likely fail?  What could you do to make it more robust?

I think more training data is necessary to improve the accuracy of the vehicle identification. My accuracy of the model is 96%. It will be better if the model is more than 99% or higher accuracy. 



